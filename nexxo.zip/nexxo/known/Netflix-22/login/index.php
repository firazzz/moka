<?php
header('Location: login');
?>